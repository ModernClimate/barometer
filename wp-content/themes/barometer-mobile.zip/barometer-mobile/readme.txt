Clean Start

---

Minimal theme created as a starting point for custom theme development. Stripped down to the bare 
minimum templates and markup for a functional theme.

---

v1.1 01.31.2012
Updated jQuery version

v1.0 10.25.2011
