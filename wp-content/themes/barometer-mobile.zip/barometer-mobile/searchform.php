<form method="get" action="<?php bloginfo('url'); ?>/">
  <input name="s" type="text" />
  <input type="submit" value="Search" />
</form>